package com.example.targetesp;

/**
 * Halkanin hedef uzerinde hangi yukseklikte gosterilecegini belirler.
 */
public enum TargetEspPosition {
    HEAD("Head"),
    CENTER("Center"),
    FEET("Feet");

    public final String label;

    TargetEspPosition(String label) {
        this.label = label;
    }
}
