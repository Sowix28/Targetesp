package com.example.targetesp;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;

/**
 * DrawContext.drawTexture(...) "gui atlas" sprite'lari bekliyor ve
 * bizim gibi tekil/ozel PNG dosyalarini gostermeyebiliyor. Bunun
 * yerine, TargetRingRenderer'daki gibi kanitlanmis calisan manuel
 * shader ciziminiburada da (2D GUI uzerinde) kullaniyoruz.
 */
public final class TargetEspGuiUtil {
    private TargetEspGuiUtil() {}

    public static void drawTexturedQuad(DrawContext context, Identifier texture, int x, int y, int width, int height) {
        Matrix4f model = context.getMatrices().peek().getPositionMatrix();

        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();

        BufferBuilder buffer = Tessellator.getInstance()
                .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        buffer.vertex(model, x, y, 0).texture(0, 0).color(1f, 1f, 1f, 1f);
        buffer.vertex(model, x, y + height, 0).texture(0, 1).color(1f, 1f, 1f, 1f);
        buffer.vertex(model, x + width, y + height, 0).texture(1, 1).color(1f, 1f, 1f, 1f);
        buffer.vertex(model, x + width, y, 0).texture(1, 0).color(1f, 1f, 1f, 1f);

        BufferRenderer.drawWithGlobalProgram(buffer.end());

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
