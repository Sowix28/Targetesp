package com.example.targetesp;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * "Custom" renk secildiginde acilan, Red/Green/Blue/Opacity
 * kaydiraclariyla (0-255) renk ayarlama ekrani.
 */
public class TargetEspCustomColorScreen extends Screen {

    private static final Identifier BACKGROUND_TEXTURE = Identifier.of("targetesp", "textures/gui/menu_background.png");

    private final Screen parent;

    private int panelLeft;
    private int panelTop;
    private static final int PANEL_WIDTH = 260;
    private static final int PANEL_HEIGHT = 230;

    public TargetEspCustomColorScreen(Screen parent) {
        super(Text.literal("Custom Color"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();

        this.panelLeft = this.width / 2 - PANEL_WIDTH / 2;
        this.panelTop = this.height / 2 - PANEL_HEIGHT / 2;
        int x = panelLeft + 20;
        int sliderWidth = PANEL_WIDTH - 40;
        int y = panelTop + 34;

        this.addDrawableChild(new IntStepSlider(x, y, sliderWidth, 20, "Red",
                0, 255, 1, TargetEspConfig.customR, value -> TargetEspConfig.customR = value));
        y += 26;

        this.addDrawableChild(new IntStepSlider(x, y, sliderWidth, 20, "Green",
                0, 255, 1, TargetEspConfig.customG, value -> TargetEspConfig.customG = value));
        y += 26;

        this.addDrawableChild(new IntStepSlider(x, y, sliderWidth, 20, "Blue",
                0, 255, 1, TargetEspConfig.customB, value -> TargetEspConfig.customB = value));
        y += 26;

        this.addDrawableChild(new IntStepSlider(x, y, sliderWidth, 20, "Opacity",
                0, 255, 1, TargetEspConfig.customAlpha, value -> TargetEspConfig.customAlpha = value));
        y += 40;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), btn -> {
                    TargetEspConfig.color = TargetEspColor.CUSTOM;
                    TargetEspConfig.save();
                    close();
                })
                .dimensions(this.width / 2 - 50, y, 100, 20)
                .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0x88000000);
        TargetEspGuiUtil.drawTexturedQuad(context, BACKGROUND_TEXTURE, panelLeft, panelTop, PANEL_WIDTH, PANEL_HEIGHT);
        context.drawBorder(panelLeft, panelTop, PANEL_WIDTH, PANEL_HEIGHT, 0xFFFFFFFF);

        super.render(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, panelTop + 10, 0xFFFFFF);

        // Canli onizleme karesi
        int previewSize = 30;
        int previewX = panelLeft + PANEL_WIDTH - previewSize - 16;
        int previewY = panelTop + PANEL_HEIGHT - previewSize - 16;
        int rgb = (TargetEspConfig.customR << 16) | (TargetEspConfig.customG << 8) | TargetEspConfig.customB;
        int argb = (TargetEspConfig.customAlpha << 24) | rgb;

        context.fill(previewX, previewY, previewX + previewSize, previewY + previewSize, 0xFF888888);
        context.fill(previewX, previewY, previewX + previewSize, previewY + previewSize, argb);
        context.drawBorder(previewX, previewY, previewSize, previewSize, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
