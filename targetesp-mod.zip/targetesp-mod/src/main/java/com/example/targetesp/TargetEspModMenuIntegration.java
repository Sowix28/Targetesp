package com.example.targetesp;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/**
 * Mod Menu yuklu ise, mod listesindeki "Configure..." butonuna
 * basildiginda bu ekran acilir. Mod Menu yuklu degilse bu sinif hic
 * cagrilmaz, mod normal calismaya devam eder.
 */
public class TargetEspModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return TargetEspScreen::new;
    }
}
