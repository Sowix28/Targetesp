package com.example.targetesp;

/**
 * Hedeften baktiktan sonra halkanin ne kadar sure daha gosterilecegini
 * belirler. OFF (0ms) secilirse hemen kaybolur.
 */
public enum TargetEspDuration {
    OFF(0L, "Off"),
    S3(3000L, "3 sec"),
    S5(5000L, "5 sec"),
    S8(8000L, "8 sec"),
    S10(10000L, "10 sec"),
    S15(15000L, "15 sec");

    public final long ms;
    public final String label;

    TargetEspDuration(long ms, String label) {
        this.ms = ms;
        this.label = label;
    }
}
