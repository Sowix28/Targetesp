package com.example.targetesp;

/**
 * Hedeften baktiktan sonra halkanin ne kadar sure daha gosterilecegini
 * belirler. OFF (0ms) secilirse hemen kaybolur.
 */
public enum TargetEspDuration {
    OFF(0L, "Kapali"),
    S3(3000L, "3sn"),
    S5(5000L, "5sn"),
    S8(8000L, "8sn"),
    S10(10000L, "10sn"),
    S15(15000L, "15sn");

    public final long ms;
    public final String label;

    TargetEspDuration(long ms, String label) {
        this.ms = ms;
        this.label = label;
    }
}
