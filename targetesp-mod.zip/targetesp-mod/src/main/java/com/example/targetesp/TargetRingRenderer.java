package com.example.targetesp;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/**
 * Hedef alinan (crosshair'in uzerinde durdugu) canliya, dunya uzayinda
 * (3D, HUD degil) donen ve renk degistiren bir halka cizer.
 *
 * K3D'nin kodu KULLANILMADI - bu sinif sifirdan yazildi.
 * Sadece texture, K3D'nin kendi asset dosyasindan alindi
 * (rounded_target_esp.png -> target_ring.png).
 */
public final class TargetRingRenderer {

    private static final Identifier RING_TEXTURE =
            Identifier.of("targetesp", "textures/gui/target_ring.png");

    private TargetRingRenderer() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(TargetRingRenderer::onRender);
    }

    private static void onRender(WorldRenderContext context) {
        if (!TargetEspConfig.enabled) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        Entity target = client.targetedEntity;
        if (!(target instanceof LivingEntity living)) return;
        if (living == client.player) return;
        if (!living.isAlive() || living.isRemoved()) return;
        if (client.player.squaredDistanceTo(living) > TargetEspConfig.MAX_DISTANCE * TargetEspConfig.MAX_DISTANCE) return;

        MatrixStack matrices = context.matrixStack();
        if (matrices == null) return;

        Vec3d camPos = context.camera().getPos();

        // Basitlik ve saglamlik icin dogrudan mevcut pozisyon kullaniliyor.
        // Daha akici (interpolated) hareket istersen entity'nin bir onceki
        // tick pozisyonuyla lerp yapabilirsin.
        double x = living.getX() - camPos.x;
        double y = living.getY() + living.getHeight() / 2.0 - camPos.y;
        double z = living.getZ() - camPos.z;

        matrices.push();
        matrices.translate(x, y, z);

        // Kameraya donuk (billboard) yap.
        matrices.multiply(context.camera().getRotation());

        // Zamanla donme.
        long now = System.currentTimeMillis();
        float spinProgress = (now % TargetEspConfig.SPIN_PERIOD_MS) / (float) TargetEspConfig.SPIN_PERIOD_MS;
        matrices.multiply(new Quaternionf().rotationZ((float) (spinProgress * Math.PI * 2)));

        // RGB renk dongusu.
        float hue = (now % TargetEspConfig.COLOR_PERIOD_MS) / (float) TargetEspConfig.COLOR_PERIOD_MS;
        int packedColor = MathHelper.hsvToRgb(hue, 0.9f, 1.0f);
        float r = ((packedColor >> 16) & 0xFF) / 255f;
        float g = ((packedColor >> 8) & 0xFF) / 255f;
        float b = (packedColor & 0xFF) / 255f;
        float a = TargetEspConfig.ALPHA;

        float size = living.getWidth() * TargetEspConfig.SIZE_MULTIPLIER + 0.35f;
        float half = size / 2f;

        VertexConsumerProvider.Immediate immediate = client.getBufferBuilders().getEntityVertexConsumers();
        RenderLayer layer = RenderLayer.getEntityTranslucentEmissive(RING_TEXTURE);
        VertexConsumer buffer = immediate.getBuffer(layer);

        Matrix4f model = matrices.peek().getPositionMatrix();
        int light = 15728880; // full-bright (parlaklikdan etkilenmesin)

        drawVertex(buffer, model, -half, -half, r, g, b, a, 0, 1, light);
        drawVertex(buffer, model, half, -half, r, g, b, a, 1, 1, light);
        drawVertex(buffer, model, half, half, r, g, b, a, 1, 0, light);
        drawVertex(buffer, model, -half, half, r, g, b, a, 0, 0, light);

        immediate.draw(layer);

        matrices.pop();
    }

    private static void drawVertex(VertexConsumer buffer, Matrix4f model, float x, float y,
                                    float r, float g, float b, float a, float u, float v, int light) {
        // NOT: Eger derleyici ".next()" metodunu bulamiyorum derse
        // (1.21.4'ten SONRAKI bir Fabric/Minecraft surumu kullaniyorsan),
        // asagidaki ".next()" satirini sil - yeni vertex API'sinde
        // her cagri otomatik tamamlanir.
        buffer.vertex(model, x, y, 0)
                .color(r, g, b, a)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(0, 1, 0);
    }
}
