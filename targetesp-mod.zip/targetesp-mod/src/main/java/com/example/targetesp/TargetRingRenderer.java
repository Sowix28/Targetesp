package com.example.targetesp;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/**
 * Hedef alinan (crosshair'in uzerinde durdugu) canliya, dunya uzayinda
 * (3D, HUD degil) donen ve renk degistiren bir halka cizer.
 *
 * Derinlik testi (depth test) BILEREK kapatiliyor, boylece halka
 * duvarin/blogun/baska bir varligin arkasinda kalsa bile her zaman
 * gorunur - bir ESP'nin asil amaci bu.
 *
 * K3D'nin kodu KULLANILMADI - bu sinif sifirdan yazildi.
 * Sadece texture, K3D'nin kendi asset dosyasindan alindi.
 */
public final class TargetRingRenderer {

    private static final Identifier RING_TEXTURE =
            Identifier.of("targetesp", "textures/gui/target_ring.png");

    private TargetRingRenderer() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(TargetRingRenderer::onRender);
    }

    // Son hedef alinan canli ve ne zaman hedef alindigi - hedef kaybedilince
    // hemen silinmesin diye kisa sure hatirlaniyor.
    private static LivingEntity lastTarget = null;
    private static long lastSeenAt = 0L;

    private static void onRender(WorldRenderContext context) {
        if (!TargetEspConfig.enabled) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        long now = System.currentTimeMillis();

        Entity currentTarget = client.targetedEntity;
        if (currentTarget instanceof LivingEntity currentLiving
                && currentLiving != client.player
                && currentLiving.isAlive()
                && !currentLiving.isRemoved()) {
            lastTarget = currentLiving;
            lastSeenAt = now;
        }

        if (lastTarget == null) return;
        if (now - lastSeenAt > TargetEspConfig.HOLD_DURATION_MS) {
            lastTarget = null;
            return;
        }

        LivingEntity living = lastTarget;
        if (!living.isAlive() || living.isRemoved()) {
            lastTarget = null;
            return;
        }
        if (client.player.squaredDistanceTo(living) > TargetEspConfig.MAX_DISTANCE * TargetEspConfig.MAX_DISTANCE) return;

        MatrixStack matrices = context.matrixStack();
        if (matrices == null) return;

        Vec3d camPos = context.camera().getPos();

        double x = living.getX() - camPos.x;
        double y = living.getY() + living.getHeight() / 2.0 - camPos.y;
        double z = living.getZ() - camPos.z;

        matrices.push();
        matrices.translate(x, y, z);

        // Kameraya donuk (billboard) yap.
        matrices.multiply(context.camera().getRotation());

        // Zamanla donme.
        float spinProgress = (now % TargetEspConfig.SPIN_PERIOD_MS) / (float) TargetEspConfig.SPIN_PERIOD_MS;
        matrices.multiply(new Quaternionf().rotationZ((float) (spinProgress * Math.PI * 2)));

        // RGB renk dongusu.
        float hue = (now % TargetEspConfig.COLOR_PERIOD_MS) / (float) TargetEspConfig.COLOR_PERIOD_MS;
        int packedColor = MathHelper.hsvToRgb(hue, 0.9f, 1.0f);
        float r = ((packedColor >> 16) & 0xFF) / 255f;
        float g = ((packedColor >> 8) & 0xFF) / 255f;
        float b = (packedColor & 0xFF) / 255f;
        float a = TargetEspConfig.ALPHA;

        float size = living.getWidth() * TargetEspConfig.SIZE_MULTIPLIER + 0.35f;
        float half = size / 2f;

        Matrix4f model = matrices.peek().getPositionMatrix();

        // --- Render durumu: derinlik testi kapali, iki taraftan da gorunur ---
        RenderSystem.setShader(GameRenderer::getPositionColorTexProgram);
        RenderSystem.setShaderTexture(0, RING_TEXTURE);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();

        BufferBuilder buffer = Tessellator.getInstance()
                .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR_TEXTURE);

        buffer.vertex(model, -half, -half, 0).color(r, g, b, a).texture(0, 1);
        buffer.vertex(model, half, -half, 0).color(r, g, b, a).texture(1, 1);
        buffer.vertex(model, half, half, 0).color(r, g, b, a).texture(1, 0);
        buffer.vertex(model, -half, half, 0).color(r, g, b, a).texture(0, 0);

        BufferRenderer.drawWithGlobalProgram(buffer.end());

        // --- Durumu geri al, sonraki normal cizimleri bozmasin ---
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();

        matrices.pop();
    }
}
