package com.example.targetesp;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/**
 * Hedef alinan (crosshair'in uzerinde durdugu) canliya, dunya uzayinda
 * (3D, HUD degil) donen ve renk degistiren bir halka cizer.
 *
 * Derinlik testi (depth test) BILEREK kapatiliyor, boylece halka
 * duvarin/blogun/baska bir varligin arkasinda kalsa bile her zaman
 * gorunur - bir ESP'nin asil amaci bu.
 *
 * K3D'nin kodu KULLANILMADI - bu sinif sifirdan yazildi.
 * Sadece texture, K3D'nin kendi asset dosyasindan alindi.
 */
public final class TargetRingRenderer {

    private TargetRingRenderer() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(TargetRingRenderer::onRender);
    }

    // Son hedef alinan canli ve ne zaman hedef alindigi - hedef kaybedilince
    // hemen silinmesin diye kisa sure hatirlaniyor.
    private static LivingEntity lastTarget = null;
    private static long lastSeenAt = 0L;

    private static void onRender(WorldRenderContext context) {
        if (!TargetEspConfig.enabled) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        long now = System.currentTimeMillis();

        Entity currentTarget = client.targetedEntity;
        if (currentTarget instanceof LivingEntity currentLiving
                && currentLiving != client.player
                && currentLiving.isAlive()
                && !currentLiving.isRemoved()) {
            lastTarget = currentLiving;
            lastSeenAt = now;
        }

        if (lastTarget == null) return;
        long holdMs = TargetEspConfig.duration.ms;
        if (now - lastSeenAt > holdMs) {
            lastTarget = null;
            return;
        }

        LivingEntity living = lastTarget;
        if (!living.isAlive() || living.isRemoved()) {
            lastTarget = null;
            return;
        }
        if (client.player.squaredDistanceTo(living) > TargetEspConfig.MAX_DISTANCE * TargetEspConfig.MAX_DISTANCE) return;

        MatrixStack matrices = context.matrixStack();
        if (matrices == null) return;

        Vec3d camPos = context.camera().getPos();

        double x = living.getX() - camPos.x;
        double y;
        switch (TargetEspConfig.position) {
            case HEAD -> y = living.getY() + living.getHeight() - camPos.y;
            case FEET -> y = living.getY() - camPos.y;
            default -> y = living.getY() + living.getHeight() / 2.0 - camPos.y;
        }
        double z = living.getZ() - camPos.z;

        matrices.push();
        matrices.translate(x, y, z);

        // Kameraya donuk (billboard) yap.
        matrices.multiply(context.camera().getRotation());

        // Zamanla donme (kapatilmissa hic donmez).
        if (TargetEspConfig.spinEnabled) {
            long spinPeriod = TargetEspConfig.turnSpeedPeriodMs();
            float spinProgress = (now % spinPeriod) / (float) spinPeriod;
            matrices.multiply(new Quaternionf().rotationZ((float) (spinProgress * Math.PI * 2)));
        }

        // Secili renk: Chroma ise zamanla RGB doner, Custom ise kullanicinin
        // kendi ayarladigi deger, digerleri sabit renk.
        float r;
        float g;
        float b;
        float a;
        if (TargetEspConfig.color.chroma) {
            float hue = (now % TargetEspConfig.COLOR_PERIOD_MS) / (float) TargetEspConfig.COLOR_PERIOD_MS;
            int packedColor = MathHelper.hsvToRgb(hue, 0.9f, 1.0f);
            r = ((packedColor >> 16) & 0xFF) / 255f;
            g = ((packedColor >> 8) & 0xFF) / 255f;
            b = (packedColor & 0xFF) / 255f;
            a = TargetEspConfig.ALPHA;
        } else if (TargetEspConfig.color.custom) {
            r = TargetEspConfig.customRFloat();
            g = TargetEspConfig.customGFloat();
            b = TargetEspConfig.customBFloat();
            a = TargetEspConfig.customAlphaFloat();
        } else {
            r = TargetEspConfig.color.r;
            g = TargetEspConfig.color.g;
            b = TargetEspConfig.color.b;
            a = TargetEspConfig.ALPHA;
        }

        float size = living.getWidth() * TargetEspConfig.sizeMultiplier() + 0.35f;
        float half = size / 2f;

        Matrix4f model = matrices.peek().getPositionMatrix();
        Identifier ringTexture = TargetEspConfig.style.textureId();

        // --- Render durumu: derinlik testi kapali, iki taraftan da gorunur ---
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, ringTexture);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();

        BufferBuilder buffer = Tessellator.getInstance()
                .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        buffer.vertex(model, -half, -half, 0).texture(0, 1).color(r, g, b, a);
        buffer.vertex(model, half, -half, 0).texture(1, 1).color(r, g, b, a);
        buffer.vertex(model, half, half, 0).texture(1, 0).color(r, g, b, a);
        buffer.vertex(model, -half, half, 0).texture(0, 0).color(r, g, b, a);

        BufferRenderer.drawWithGlobalProgram(buffer.end());

        // --- Durumu geri al, sonraki normal cizimleri bozmasin ---
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();

        matrices.pop();
    }
}
