package com.example.targetesp;

/**
 * Halkanin renk secenekleri. CHROMA secilirse renk zamanla RGB
 * spektrumunda doner (eski davranis), digerleri sabit bir renktir.
 */
public enum TargetEspColor {
    CHROMA(1f, 1f, 1f, true, "Chroma"),
    RED(1f, 0.15f, 0.15f, false, "Kirmizi"),
    GREEN(0.2f, 1f, 0.2f, false, "Yesil"),
    BLUE(0.25f, 0.5f, 1f, false, "Mavi"),
    YELLOW(1f, 0.9f, 0.1f, false, "Sari"),
    PURPLE(0.7f, 0.25f, 1f, false, "Mor"),
    CYAN(0.15f, 0.95f, 1f, false, "Turkuaz");

    public final float r;
    public final float g;
    public final float b;
    public final boolean chroma;
    public final String label;

    TargetEspColor(float r, float g, float b, boolean chroma, String label) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.chroma = chroma;
        this.label = label;
    }

    /** Buton metni icin 0xRRGGBB paketlenmis renk. */
    public int packedRgb() {
        int ir = Math.round(r * 255f);
        int ig = Math.round(g * 255f);
        int ib = Math.round(b * 255f);
        return (ir << 16) | (ig << 8) | ib;
    }
}
