package com.example.targetesp;

/**
 * Halkanin renk secenekleri. CHROMA secilirse renk zamanla RGB
 * spektrumunda doner. CUSTOM secilirse TargetEspConfig'teki
 * kullanicinin kendi ayarladigi R/G/B/Opacity degerleri kullanilir.
 */
public enum TargetEspColor {
    CHROMA(1f, 1f, 1f, true, false, "Chromatic"),
    RED(1f, 0.15f, 0.15f, false, false, "Red"),
    GREEN(0.2f, 1f, 0.2f, false, false, "Green"),
    BLUE(0.25f, 0.5f, 1f, false, false, "Blue"),
    YELLOW(1f, 0.9f, 0.1f, false, false, "Yellow"),
    PURPLE(0.7f, 0.25f, 1f, false, false, "Purple"),
    CYAN(0.15f, 0.95f, 1f, false, false, "Cyan"),
    CUSTOM(1f, 1f, 1f, false, true, "Custom");

    public final float r;
    public final float g;
    public final float b;
    public final boolean chroma;
    public final boolean custom;
    public final String label;

    TargetEspColor(float r, float g, float b, boolean chroma, boolean custom, String label) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.chroma = chroma;
        this.custom = custom;
        this.label = label;
    }

    /** Buton metni icin 0xRRGGBB paketlenmis renk (sabit renkler icin). */
    public int packedRgb() {
        int ir = Math.round(r * 255f);
        int ig = Math.round(g * 255f);
        int ib = Math.round(b * 255f);
        return (ir << 16) | (ig << 8) | ib;
    }
}
