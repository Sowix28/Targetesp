package com.example.targetesp;

import net.fabricmc.api.ClientModInitializer;

/**
 * TargetESP - hedef alinan (baktigin) canliya donen, renk degistiren
 * (RGB) bir halka cizen basit, temiz-oda (clean-room) bir Fabric mod'u.
 *
 * K3D'nin kodu kullanilmadi; sadece K3D icindeki gorsel davranis
 * (donen halka) baz alinarak sifirdan yazildi. Texture de K3D'nin
 * kendi asset dosyasindan (rounded_target_esp.png) alindi.
 */
public class TargetEspMod implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        TargetEspConfig.load();
        TargetEspKeybind.register();
        TargetRingRenderer.register();
    }
}
