package com.example.targetesp;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class TargetEspKeybind {
    private static KeyBinding TOGGLE_KEY;

    private TargetEspKeybind() {}

    public static void register() {
        TOGGLE_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.targetesp.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_T,
                "category.targetesp"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (TOGGLE_KEY.wasPressed()) {
                TargetEspConfig.enabled = !TargetEspConfig.enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                            net.minecraft.text.Text.literal(
                                    "[TargetESP] " + (TargetEspConfig.enabled ? "Acik" : "Kapali")
                            ),
                            true
                    );
                }
            }
        });
    }
}
