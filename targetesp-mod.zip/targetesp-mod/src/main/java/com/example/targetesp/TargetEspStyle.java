package com.example.targetesp;

import net.minecraft.util.Identifier;

/**
 * Halkanin gorsel sekli (texture) secenekleri.
 */
public enum TargetEspStyle {
    RING("Ring", "textures/gui/style_ring.png"),
    BRACKETS("Brackets", "textures/gui/style_brackets.png"),
    ARROWS("Arrows", "textures/gui/style_arrows.png"),
    DIAMOND("Diamond", "textures/gui/style_diamond.png"),
    CROSS("Cross", "textures/gui/style_cross.png"),
    DOTS("Dots", "textures/gui/style_dots.png");

    public final String label;
    private final String texturePath;

    TargetEspStyle(String label, String texturePath) {
        this.label = label;
        this.texturePath = texturePath;
    }

    public Identifier textureId() {
        return Identifier.of("targetesp", texturePath);
    }
}
