package com.example.targetesp;

import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

/**
 * min-max araliginda, belirli adimlarla (step) ilerleyen genel amacli
 * bir kaydirac. Hem Custom renk (0-255) hem de Size (10-100) icin
 * kullanilir.
 */
public class IntStepSlider extends SliderWidget {

    public interface ValueSetter {
        void set(int value);
    }

    private final String label;
    private final int min;
    private final int max;
    private final int step;
    private final ValueSetter setter;

    public IntStepSlider(int x, int y, int width, int height, String label,
                          int min, int max, int step, int initialValue, ValueSetter setter) {
        super(x, y, width, height, Text.literal(label + ": " + initialValue), normalize(initialValue, min, max));
        this.label = label;
        this.min = min;
        this.max = max;
        this.step = step;
        this.setter = setter;
    }

    private static double normalize(int value, int min, int max) {
        if (max == min) return 0.0;
        return (value - min) / (double) (max - min);
    }

    private int currentValue() {
        int raw = min + (int) Math.round(this.value * (max - min));
        int stepsFromMin = Math.round((raw - min) / (float) step);
        int stepped = min + stepsFromMin * step;
        return Math.max(min, Math.min(max, stepped));
    }

    @Override
    protected void updateMessage() {
        this.setMessage(Text.literal(label + ": " + currentValue()));
    }

    @Override
    protected void applyValue() {
        setter.set(currentValue());
    }
}
