package com.example.targetesp;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Ayarlar ve basit dosyaya kaydetme/yukleme. Ayar dosyasi
 * config/targetesp.properties konumunda tutulur.
 */
public final class TargetEspConfig {
    private TargetEspConfig() {}

    /** Mod acik mi kapali mi (varsayilan tus J ile ac/kapa). */
    public static boolean enabled = true;

    /** Secili renk (varsayilan: Chroma / RGB donen). */
    public static TargetEspColor color = TargetEspColor.CHROMA;

    /** Hedeften bakmayi biraktiktan sonra ne kadar sure daha gosterilsin. */
    public static TargetEspDuration duration = TargetEspDuration.S3;

    /** Halkanin bir tam donusunu tamamlama suresi (milisaniye). */
    public static final long SPIN_PERIOD_MS = 7000L;

    /** Chroma modunda renk donguzunun tam tur suresi (milisaniye). */
    public static final long COLOR_PERIOD_MS = 2500L;

    /** Halka boyutu carpani (hedefin genisligine gore). */
    public static final float SIZE_MULTIPLIER = 0.75f;

    /** Halkanin saydamligi (0.0 - 1.0). */
    public static final float ALPHA = 0.95f;

    /** Kac blok mesafeye kadar hedef aransin. */
    public static final double MAX_DISTANCE = 64.0;

    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("targetesp.properties");
    }

    public static void load() {
        Path path = configPath();
        if (!Files.exists(path)) return;

        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            props.load(in);
        } catch (IOException e) {
            return; // ayar dosyasi okunamadi, varsayilanlarla devam edilir
        }

        enabled = Boolean.parseBoolean(props.getProperty("enabled", Boolean.toString(enabled)));

        try {
            color = TargetEspColor.valueOf(props.getProperty("color", color.name()));
        } catch (IllegalArgumentException ignored) {
            // bilinmeyen deger, varsayilan korunur
        }

        try {
            duration = TargetEspDuration.valueOf(props.getProperty("duration", duration.name()));
        } catch (IllegalArgumentException ignored) {
            // bilinmeyen deger, varsayilan korunur
        }
    }

    public static void save() {
        Properties props = new Properties();
        props.setProperty("enabled", Boolean.toString(enabled));
        props.setProperty("color", color.name());
        props.setProperty("duration", duration.name());

        try {
            Path path = configPath();
            Files.createDirectories(path.getParent());
            try (OutputStream out = Files.newOutputStream(path)) {
                props.store(out, "TargetESP ayarlari");
            }
        } catch (IOException ignored) {
            // ayar dosyasi yazilamadi, ayarlar bu oturumda gecerli kalmaya devam eder
        }
    }
}
