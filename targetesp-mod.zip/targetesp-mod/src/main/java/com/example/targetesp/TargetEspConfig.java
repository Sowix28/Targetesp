package com.example.targetesp;

/**
 * Basit ayarlar. Degerleri buradan degistirip tekrar derleyebilirsin.
 */
public final class TargetEspConfig {
    private TargetEspConfig() {}

    /** Mod acik mi kapali mi (T tusuyla ac/kapa). */
    public static boolean enabled = true;

    /** Halkanin bir tam donusunu tamamlama suresi (milisaniye). Kucuk = daha hizli doner. */
    public static final long SPIN_PERIOD_MS = 3000L;

    /** RGB renginin bir tam dongusunu tamamlama suresi (milisaniye). */
    public static final long COLOR_PERIOD_MS = 2500L;

    /** Halka boyutu carpani (hedefin genisligine gore). */
    public static final float SIZE_MULTIPLIER = 1.6f;

    /** Halkanin saydamligi (0.0 - 1.0). */
    public static final float ALPHA = 0.95f;

    /** Kac blok mesafeye kadar hedef aransin. */
    public static final double MAX_DISTANCE = 64.0;
}
