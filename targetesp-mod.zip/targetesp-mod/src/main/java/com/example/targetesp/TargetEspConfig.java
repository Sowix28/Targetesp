package com.example.targetesp;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Ayarlar ve basit dosyaya kaydetme/yukleme. Ayar dosyasi
 * config/targetesp.properties konumunda tutulur.
 */
public final class TargetEspConfig {
    private TargetEspConfig() {}

    /** Mod acik mi kapali mi. */
    public static boolean enabled = true;

    /** Secili renk (varsayilan: Chroma / RGB donen). */
    public static TargetEspColor color = TargetEspColor.CHROMA;

    /** Secili sekil/gorunum (varsayilan: Brackets - onceki hali). */
    public static TargetEspStyle style = TargetEspStyle.BRACKETS;

    /** Boyut degeri, 10-100 araliginda (10'ar 10'ar). Varsayilan 50 = eski boyut. */
    public static int sizeValue = 50;

    /** Donme hizi degeri, 10-200 araliginda. Varsayilan 100 = eski hiz. */
    public static int turnSpeedValue = 100;

    /** Halkanin donme tamamen kapali mi (true ise halka sabit durur, donmez). */
    public static boolean spinEnabled = true;

    /** Halkanin hedef uzerinde gosterilecegi yukseklik. */
    public static TargetEspPosition position = TargetEspPosition.CENTER;

    /** Hedeften bakmayi biraktiktan sonra ne kadar sure daha gosterilsin. */
    public static TargetEspDuration duration = TargetEspDuration.S3;

    /** Custom renk - R/G/B/Opacity, 0-255 araliginda. */
    public static int customR = 192;
    public static int customG = 157;
    public static int customB = 241;
    public static int customAlpha = 200;

    /** Chroma modunda renk donguzunun tam tur suresi (milisaniye). */
    public static final long COLOR_PERIOD_MS = 2500L;

    /** Sabit renkler icin saydamlik (0.0 - 1.0). Custom renk kendi opacity'sini kullanir. */
    public static final float ALPHA = 0.95f;

    /** Kac blok mesafeye kadar hedef aransin. */
    public static final double MAX_DISTANCE = 64.0;

    /** Boyut carpani: sizeValue=50 -> 0.75 (eski varsayilan), 10 -> 0.15, 100 -> 1.5. */
    public static float sizeMultiplier() {
        return (sizeValue / 50f) * 0.75f;
    }

    /** Donme hizindan gercek donus suresini (ms) hesaplar. turnSpeedValue=100 -> 7000ms (eski varsayilan). */
    public static long turnSpeedPeriodMs() {
        return Math.round(700000.0 / turnSpeedValue);
    }

    public static float customRFloat() {
        return customR / 255f;
    }

    public static float customGFloat() {
        return customG / 255f;
    }

    public static float customBFloat() {
        return customB / 255f;
    }

    public static float customAlphaFloat() {
        return customAlpha / 255f;
    }

    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("targetesp.properties");
    }

    public static void load() {
        Path path = configPath();
        if (!Files.exists(path)) return;

        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            props.load(in);
        } catch (IOException e) {
            return; // ayar dosyasi okunamadi, varsayilanlarla devam edilir
        }

        enabled = Boolean.parseBoolean(props.getProperty("enabled", Boolean.toString(enabled)));

        try {
            color = TargetEspColor.valueOf(props.getProperty("color", color.name()));
        } catch (IllegalArgumentException ignored) {
            // bilinmeyen deger, varsayilan korunur
        }

        try {
            style = TargetEspStyle.valueOf(props.getProperty("style", style.name()));
        } catch (IllegalArgumentException ignored) {
            // bilinmeyen deger, varsayilan korunur
        }

        try {
            duration = TargetEspDuration.valueOf(props.getProperty("duration", duration.name()));
        } catch (IllegalArgumentException ignored) {
            // bilinmeyen deger, varsayilan korunur
        }

        sizeValue = parseIntClamped(props.getProperty("sizeValue"), sizeValue, 10, 200);
        sizeValue = (sizeValue / 5) * 5; // 5'in katina yuvarla

        turnSpeedValue = parseIntClamped(props.getProperty("turnSpeedValue"), turnSpeedValue, 10, 400);
        turnSpeedValue = (turnSpeedValue / 5) * 5;

        spinEnabled = Boolean.parseBoolean(props.getProperty("spinEnabled", Boolean.toString(spinEnabled)));

        try {
            position = TargetEspPosition.valueOf(props.getProperty("position", position.name()));
        } catch (IllegalArgumentException ignored) {
            // bilinmeyen deger, varsayilan korunur
        }

        customR = parseIntClamped(props.getProperty("customR"), customR, 0, 255);
        customG = parseIntClamped(props.getProperty("customG"), customG, 0, 255);
        customB = parseIntClamped(props.getProperty("customB"), customB, 0, 255);
        customAlpha = parseIntClamped(props.getProperty("customAlpha"), customAlpha, 0, 255);
    }

    private static int parseIntClamped(String value, int fallback, int min, int max) {
        if (value == null) return fallback;
        try {
            int parsed = Integer.parseInt(value.trim());
            return Math.max(min, Math.min(max, parsed));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    public static void save() {
        Properties props = new Properties();
        props.setProperty("enabled", Boolean.toString(enabled));
        props.setProperty("color", color.name());
        props.setProperty("style", style.name());
        props.setProperty("duration", duration.name());
        props.setProperty("sizeValue", Integer.toString(sizeValue));
        props.setProperty("turnSpeedValue", Integer.toString(turnSpeedValue));
        props.setProperty("spinEnabled", Boolean.toString(spinEnabled));
        props.setProperty("position", position.name());
        props.setProperty("customR", Integer.toString(customR));
        props.setProperty("customG", Integer.toString(customG));
        props.setProperty("customB", Integer.toString(customB));
        props.setProperty("customAlpha", Integer.toString(customAlpha));

        try {
            Path path = configPath();
            Files.createDirectories(path.getParent());
            try (OutputStream out = Files.newOutputStream(path)) {
                props.store(out, "TargetRing ayarlari");
            }
        } catch (IOException ignored) {
            // ayar dosyasi yazilamadi, ayarlar bu oturumda gecerli kalmaya devam eder
        }
    }
}
