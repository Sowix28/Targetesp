package com.example.targetesp;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/**
 * TargetRing icin ozel ayar ekrani. Renk, sure ve tus atamalarini
 * degistirmeye yariyor. Hem oyun ici tusla, hem de Mod Menu
 * ("Configure...") uzerinden acilabilir.
 *
 * Tum Y konumlari TEK bir yerden, sirayla (panelTop'tan baslayarak)
 * hesaplanir - ayni sayi iki farkli yerde tekrar yazilmaz, bu yuzden
 * etiketlerle butonlarin cakisma riski yok.
 */
public class TargetEspScreen extends Screen {

    private final Screen parent;

    private ButtonWidget menuKeyButton;
    private ButtonWidget toggleKeyButton;

    /** Su an hangi tus atamasi icin yeni tus bekleniyor (null ise bekleme yok). */
    private KeyBinding listeningFor = null;

    private int panelLeft;
    private int panelTop;
    private static final int PANEL_WIDTH = 320;
    private static final int PANEL_HEIGHT = 300;

    private int colorsLabelY;
    private int durationLabelY;
    private int keyBindingsLabelY;

    public TargetEspScreen(Screen parent) {
        super(Text.literal("TargetRing Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();

        int centerX = this.width / 2;
        this.panelLeft = centerX - PANEL_WIDTH / 2;
        this.panelTop = this.height / 2 - PANEL_HEIGHT / 2;

        int y = panelTop + 26;

        colorsLabelY = y;
        y += 14;
        y = addColorButtons(centerX, y);

        y += 12;
        durationLabelY = y;
        y += 14;
        y = addDurationButtons(centerX, y);

        y += 14;
        keyBindingsLabelY = y;
        y += 16;

        int keyBtnWidth = 270;
        int keyBtnX = centerX - keyBtnWidth / 2;

        menuKeyButton = ButtonWidget.builder(Text.literal(""), btn -> {
                    listeningFor = TargetEspKeybind.getMenuKey();
                    refreshKeybindLabels();
                })
                .dimensions(keyBtnX, y, keyBtnWidth, 20)
                .build();
        this.addDrawableChild(menuKeyButton);
        y += 24;

        toggleKeyButton = ButtonWidget.builder(Text.literal(""), btn -> {
                    listeningFor = TargetEspKeybind.getToggleKey();
                    refreshKeybindLabels();
                })
                .dimensions(keyBtnX, y, keyBtnWidth, 20)
                .build();
        this.addDrawableChild(toggleKeyButton);
        refreshKeybindLabels();
        y += 30;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Exit"), btn -> close())
                .dimensions(centerX - 50, y, 100, 20)
                .build());
    }

    private int addColorButtons(int centerX, int y) {
        TargetEspColor[] colors = TargetEspColor.values(); // 8 adet
        int btnW = 68;
        int btnH = 20;
        int gap = 4;

        placeRow(centerX, y, btnW, btnH, gap, colors, 0, 4);
        y += btnH + gap;
        placeRow(centerX, y, btnW, btnH, gap, colors, 4, 8);
        y += btnH;
        return y;
    }

    private void placeRow(int centerX, int y, int btnW, int btnH, int gap,
                           TargetEspColor[] colors, int fromIndex, int toIndex) {
        int count = toIndex - fromIndex;
        int totalWidth = count * btnW + (count - 1) * gap;
        int x = centerX - totalWidth / 2;

        for (int i = fromIndex; i < toIndex; i++) {
            TargetEspColor c = colors[i];
            boolean selected = TargetEspConfig.color == c;
            ButtonWidget button = ButtonWidget.builder(colorLabel(c, selected), btn -> {
                        if (c.custom) {
                            if (this.client != null) {
                                this.client.setScreen(new TargetEspCustomColorScreen(this));
                            }
                        } else {
                            TargetEspConfig.color = c;
                            TargetEspConfig.save();
                            rebuild();
                        }
                    })
                    .dimensions(x, y, btnW, btnH)
                    .build();
            this.addDrawableChild(button);
            x += btnW + gap;
        }
    }

    private Text colorLabel(TargetEspColor c, boolean selected) {
        String prefix = selected ? "> " : "";
        String suffix = selected ? " <" : "";

        if (c.chroma) {
            MutableText result = Text.literal(prefix);
            String word = c.label;
            for (int i = 0; i < word.length(); i++) {
                float hue = (float) i / word.length();
                int rgb = MathHelper.hsvToRgb(hue, 0.85f, 1f) & 0xFFFFFF;
                result = result.append(Text.literal(String.valueOf(word.charAt(i))).withColor(rgb));
            }
            return result.append(Text.literal(suffix));
        }

        if (c.custom) {
            int rgb = (TargetEspConfig.customR << 16) | (TargetEspConfig.customG << 8) | TargetEspConfig.customB;
            return Text.literal(prefix + c.label + suffix).withColor(rgb);
        }

        return Text.literal(prefix + c.label + suffix).withColor(c.packedRgb());
    }

    private int addDurationButtons(int centerX, int y) {
        TargetEspDuration[] durations = TargetEspDuration.values();
        int btnW = 68;
        int btnH = 18;
        int gap = 4;

        placeDurationRow(centerX, y, btnW, btnH, gap, durations, 0, 3);
        y += btnH + gap;
        placeDurationRow(centerX, y, btnW, btnH, gap, durations, 3, 6);
        y += btnH;
        return y;
    }

    private void placeDurationRow(int centerX, int y, int btnW, int btnH, int gap,
                                   TargetEspDuration[] durations, int fromIndex, int toIndex) {
        int count = toIndex - fromIndex;
        int totalWidth = count * btnW + (count - 1) * gap;
        int x = centerX - totalWidth / 2;

        for (int i = fromIndex; i < toIndex; i++) {
            TargetEspDuration d = durations[i];
            boolean selected = TargetEspConfig.duration == d;
            String text = (selected ? "> " : "") + d.label + (selected ? " <" : "");
            ButtonWidget button = ButtonWidget.builder(
                            Text.literal(text).formatted(selected ? Formatting.YELLOW : Formatting.GRAY),
                            btn -> {
                                TargetEspConfig.duration = d;
                                TargetEspConfig.save();
                                rebuild();
                            })
                    .dimensions(x, y, btnW, btnH)
                    .build();
            this.addDrawableChild(button);
            x += btnW + gap;
        }
    }

    private void rebuild() {
        if (this.client != null) {
            this.client.setScreen(new TargetEspScreen(parent));
        }
    }

    private void refreshKeybindLabels() {
        boolean waitingMenu = listeningFor == TargetEspKeybind.getMenuKey();
        boolean waitingToggle = listeningFor == TargetEspKeybind.getToggleKey();

        menuKeyButton.setMessage(waitingMenu
                ? Text.literal("Open Menu > Press a key...").formatted(Formatting.YELLOW)
                : Text.literal("Open Menu: ").append(TargetEspKeybind.getMenuKey().getBoundKeyLocalizedText()));

        toggleKeyButton.setMessage(waitingToggle
                ? Text.literal("Toggle TargetRing > Press a key...").formatted(Formatting.YELLOW)
                : Text.literal("Toggle TargetRing: ").append(TargetEspKeybind.getToggleKey().getBoundKeyLocalizedText()));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listeningFor != null) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                listeningFor.setBoundKey(InputUtil.Type.KEYSYM.createFromCode(keyCode));
                KeyBinding.updateKeysByCode();
                if (this.client != null) {
                    this.client.options.write();
                }
            }
            listeningFor = null;
            refreshKeybindLabels();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0x88000000);

        context.fill(panelLeft, panelTop, panelLeft + PANEL_WIDTH, panelTop + PANEL_HEIGHT, 0xE6101018);
        context.drawBorder(panelLeft, panelTop, PANEL_WIDTH, PANEL_HEIGHT, 0xFF4A4A6A);

        super.render(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, panelTop + 10, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Colors"),
                this.width / 2, colorsLabelY, 0xAAAAAA);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Duration"),
                this.width / 2, durationLabelY, 0xAAAAAA);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Key Bindings"),
                this.width / 2, keyBindingsLabelY, 0xAAAAAA);
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
