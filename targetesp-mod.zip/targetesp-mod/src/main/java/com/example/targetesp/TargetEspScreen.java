package com.example.targetesp;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/**
 * TargetRing icin ozel ayar ekrani. Renk, sekil, boyut, sure ve tus
 * atamalarini degistirmeye yariyor. Hem oyun ici tusla, hem de
 * Mod Menu ("Configure...") uzerinden acilabilir.
 *
 * Tum Y konumlari TEK bir yerden, sirayla (panelTop'tan baslayarak)
 * hesaplanir - ayni sayi iki farkli yerde tekrar yazilmaz.
 */
public class TargetEspScreen extends Screen {

    private static final Identifier BACKGROUND_TEXTURE = Identifier.of("targetesp", "textures/gui/menu_background.png");
    private static final int BACKGROUND_TEX_SIZE_W = 320;
    private static final int BACKGROUND_TEX_SIZE_H = 380;

    /** Renk butonlarinin ekranda gosterilecegi sira (Custom, Chroma'nin hemen altinda). */
    private static final TargetEspColor[] COLOR_DISPLAY_ORDER = {
            TargetEspColor.CHROMA, TargetEspColor.RED, TargetEspColor.GREEN, TargetEspColor.BLUE,
            TargetEspColor.CUSTOM, TargetEspColor.YELLOW, TargetEspColor.PURPLE, TargetEspColor.CYAN
    };

    private final Screen parent;

    private ButtonWidget menuKeyButton;
    private ButtonWidget toggleKeyButton;

    private KeyBinding listeningFor = null;

    private int panelLeft;
    private int panelTop;
    private static final int PANEL_WIDTH = 320;
    private static final int PANEL_HEIGHT = 380;

    private int colorsLabelY;
    private int styleLabelY;
    private int sizeLabelY;
    private int durationLabelY;
    private int keyBindingsLabelY;

    public TargetEspScreen(Screen parent) {
        super(Text.literal("TargetRing Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();

        int centerX = this.width / 2;
        this.panelLeft = centerX - PANEL_WIDTH / 2;
        this.panelTop = this.height / 2 - PANEL_HEIGHT / 2;

        int y = panelTop + 26;

        // --- Colors ---
        colorsLabelY = y;
        y += 14;
        y = addColorButtons(centerX, y);

        // --- Style ---
        y += 12;
        styleLabelY = y;
        y += 14;
        y = addStyleButtons(centerX, y);

        // --- Size ---
        y += 12;
        sizeLabelY = y;
        y += 14;
        int sliderWidth = 260;
        this.addDrawableChild(new IntStepSlider(centerX - sliderWidth / 2, y, sliderWidth, 20,
                "Size", 10, 100, 10, TargetEspConfig.sizeValue, value -> {
            TargetEspConfig.sizeValue = value;
            TargetEspConfig.save();
        }));
        y += 20;

        // --- Duration ---
        y += 14;
        durationLabelY = y;
        y += 14;
        y = addDurationButtons(centerX, y);

        // --- Key Bindings ---
        y += 14;
        keyBindingsLabelY = y;
        y += 16;

        int keyBtnWidth = 270;
        int keyBtnX = centerX - keyBtnWidth / 2;

        menuKeyButton = ButtonWidget.builder(Text.literal(""), btn -> {
                    listeningFor = TargetEspKeybind.getMenuKey();
                    refreshKeybindLabels();
                })
                .dimensions(keyBtnX, y, keyBtnWidth, 20)
                .build();
        this.addDrawableChild(menuKeyButton);
        y += 24;

        toggleKeyButton = ButtonWidget.builder(Text.literal(""), btn -> {
                    listeningFor = TargetEspKeybind.getToggleKey();
                    refreshKeybindLabels();
                })
                .dimensions(keyBtnX, y, keyBtnWidth, 20)
                .build();
        this.addDrawableChild(toggleKeyButton);
        refreshKeybindLabels();
        y += 30;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Exit"), btn -> close())
                .dimensions(centerX - 50, y, 100, 20)
                .build());
    }

    private int addColorButtons(int centerX, int y) {
        int btnW = 68;
        int btnH = 20;
        int gap = 4;

        placeColorRow(centerX, y, btnW, btnH, gap, 0, 4);
        y += btnH + gap;
        placeColorRow(centerX, y, btnW, btnH, gap, 4, 8);
        y += btnH;
        return y;
    }

    private void placeColorRow(int centerX, int y, int btnW, int btnH, int gap, int fromIndex, int toIndex) {
        int count = toIndex - fromIndex;
        int totalWidth = count * btnW + (count - 1) * gap;
        int x = centerX - totalWidth / 2;

        for (int i = fromIndex; i < toIndex; i++) {
            TargetEspColor c = COLOR_DISPLAY_ORDER[i];
            boolean selected = TargetEspConfig.color == c;
            ButtonWidget button = ButtonWidget.builder(colorLabel(c, selected), btn -> {
                        if (c.custom) {
                            if (this.client != null) {
                                this.client.setScreen(new TargetEspCustomColorScreen(this));
                            }
                        } else {
                            TargetEspConfig.color = c;
                            TargetEspConfig.save();
                            rebuild();
                        }
                    })
                    .dimensions(x, y, btnW, btnH)
                    .build();
            this.addDrawableChild(button);
            x += btnW + gap;
        }
    }

    /** Oklar ("> " / " <") her zaman beyaz kalir, sadece isim renklenir. */
    private Text colorLabel(TargetEspColor c, boolean selected) {
        MutableText result = Text.literal("");
        if (selected) {
            result = result.append(Text.literal("> ").formatted(Formatting.WHITE));
        }

        if (c.chroma) {
            String word = c.label;
            for (int i = 0; i < word.length(); i++) {
                float hue = (float) i / word.length();
                int rgb = MathHelper.hsvToRgb(hue, 0.85f, 1f) & 0xFFFFFF;
                result = result.append(Text.literal(String.valueOf(word.charAt(i))).withColor(rgb));
            }
        } else if (c.custom) {
            int rgb = (TargetEspConfig.customR << 16) | (TargetEspConfig.customG << 8) | TargetEspConfig.customB;
            result = result.append(Text.literal(c.label).withColor(rgb));
        } else {
            result = result.append(Text.literal(c.label).withColor(c.packedRgb()));
        }

        if (selected) {
            result = result.append(Text.literal(" <").formatted(Formatting.WHITE));
        }
        return result;
    }

    private int addStyleButtons(int centerX, int y) {
        TargetEspStyle[] styles = TargetEspStyle.values();
        int btnW = 90;
        int btnH = 20;
        int gap = 6;
        int count = styles.length;
        int totalWidth = count * btnW + (count - 1) * gap;
        int x = centerX - totalWidth / 2;

        for (TargetEspStyle s : styles) {
            boolean selected = TargetEspConfig.style == s;
            String text = (selected ? "> " : "") + s.label + (selected ? " <" : "");
            ButtonWidget button = ButtonWidget.builder(
                            Text.literal(text).formatted(selected ? Formatting.AQUA : Formatting.GRAY),
                            btn -> {
                                TargetEspConfig.style = s;
                                TargetEspConfig.save();
                                rebuild();
                            })
                    .dimensions(x, y, btnW, btnH)
                    .build();
            this.addDrawableChild(button);
            x += btnW + gap;
        }
        y += btnH;
        return y;
    }

    private int addDurationButtons(int centerX, int y) {
        TargetEspDuration[] durations = TargetEspDuration.values();
        int btnW = 68;
        int btnH = 18;
        int gap = 4;

        placeDurationRow(centerX, y, btnW, btnH, gap, durations, 0, 3);
        y += btnH + gap;
        placeDurationRow(centerX, y, btnW, btnH, gap, durations, 3, 6);
        y += btnH;
        return y;
    }

    private void placeDurationRow(int centerX, int y, int btnW, int btnH, int gap,
                                   TargetEspDuration[] durations, int fromIndex, int toIndex) {
        int count = toIndex - fromIndex;
        int totalWidth = count * btnW + (count - 1) * gap;
        int x = centerX - totalWidth / 2;

        for (int i = fromIndex; i < toIndex; i++) {
            TargetEspDuration d = durations[i];
            boolean selected = TargetEspConfig.duration == d;
            String text = (selected ? "> " : "") + d.label + (selected ? " <" : "");
            ButtonWidget button = ButtonWidget.builder(
                            Text.literal(text).formatted(selected ? Formatting.YELLOW : Formatting.GRAY),
                            btn -> {
                                TargetEspConfig.duration = d;
                                TargetEspConfig.save();
                                rebuild();
                            })
                    .dimensions(x, y, btnW, btnH)
                    .build();
            this.addDrawableChild(button);
            x += btnW + gap;
        }
    }

    private void rebuild() {
        if (this.client != null) {
            this.client.setScreen(new TargetEspScreen(parent));
        }
    }

    private void refreshKeybindLabels() {
        boolean waitingMenu = listeningFor == TargetEspKeybind.getMenuKey();
        boolean waitingToggle = listeningFor == TargetEspKeybind.getToggleKey();

        menuKeyButton.setMessage(waitingMenu
                ? Text.literal("Open Menu > Press a key...").formatted(Formatting.YELLOW)
                : Text.literal("Open Menu: ").append(TargetEspKeybind.getMenuKey().getBoundKeyLocalizedText()));

        toggleKeyButton.setMessage(waitingToggle
                ? Text.literal("Toggle TargetRing > Press a key...").formatted(Formatting.YELLOW)
                : Text.literal("Toggle TargetRing: ").append(TargetEspKeybind.getToggleKey().getBoundKeyLocalizedText()));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listeningFor != null) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                listeningFor.setBoundKey(InputUtil.Type.KEYSYM.createFromCode(keyCode));
                KeyBinding.updateKeysByCode();
                if (this.client != null) {
                    this.client.options.write();
                }
            }
            listeningFor = null;
            refreshKeybindLabels();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0x88000000);

        context.drawTexture(RenderLayer::getGuiTextured, BACKGROUND_TEXTURE,
                panelLeft, panelTop, PANEL_WIDTH, PANEL_HEIGHT,
                0, 0, BACKGROUND_TEX_SIZE_W, BACKGROUND_TEX_SIZE_H,
                BACKGROUND_TEX_SIZE_W, BACKGROUND_TEX_SIZE_H);
        context.drawBorder(panelLeft, panelTop, PANEL_WIDTH, PANEL_HEIGHT, 0xFF4A4A6A);

        super.render(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, panelTop + 10, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Colors"),
                this.width / 2, colorsLabelY, 0xEEEEEE);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Style"),
                this.width / 2, styleLabelY, 0xEEEEEE);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Size"),
                this.width / 2, sizeLabelY, 0xEEEEEE);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Duration"),
                this.width / 2, durationLabelY, 0xEEEEEE);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Key Bindings"),
                this.width / 2, keyBindingsLabelY, 0xEEEEEE);
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
