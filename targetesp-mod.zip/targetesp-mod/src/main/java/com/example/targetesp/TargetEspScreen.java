package com.example.targetesp;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * TargetRing icin ozel ayar ekrani. Renk, sekil, boyut, sure ve tus
 * atamalarini degistirmeye yariyor. Hem oyun ici tusla, hem de
 * Mod Menu ("Configure...") uzerinden acilabilir.
 *
 * Tum Y konumlari TEK bir yerden, sirayla (panelTop'tan baslayarak)
 * hesaplanir - ayni sayi iki farkli yerde tekrar yazilmaz.
 */
public class TargetEspScreen extends Screen {

    private static final Identifier BACKGROUND_TEXTURE = Identifier.of("targetesp", "textures/gui/menu_background.png");

    /** Renk butonlarinin ekranda gosterilecegi sira (Custom, Chroma'nin hemen altinda). */
    private static final TargetEspColor[] COLOR_DISPLAY_ORDER = {
            TargetEspColor.CHROMA, TargetEspColor.RED, TargetEspColor.GREEN, TargetEspColor.BLUE,
            TargetEspColor.CUSTOM, TargetEspColor.YELLOW, TargetEspColor.PURPLE, TargetEspColor.CYAN
    };

    private final Screen parent;

    private ButtonWidget menuKeyButton;
    private ButtonWidget toggleKeyButton;

    private KeyBinding listeningFor = null;

    /** Beyaz kenarlik cizmek icin tum widget'larin sinirlarini tutuyoruz. */
    private final List<int[]> widgetBounds = new ArrayList<>();

    private int panelLeft;
    private int panelTop;
    private static final int PANEL_WIDTH = 320;
    private static final int PANEL_HEIGHT = 500;

    private int colorsLabelY;
    private int styleLabelY;
    private int sizeLabelY;
    private int turnSpeedLabelY;
    private int durationLabelY;
    private int positionLabelY;
    private int keyBindingsLabelY;

    private ButtonWidget turnSpeedOffButton;

    public TargetEspScreen(Screen parent) {
        super(Text.literal("TargetRing Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();

        int centerX = this.width / 2;
        this.panelLeft = centerX - PANEL_WIDTH / 2;
        this.panelTop = this.height / 2 - PANEL_HEIGHT / 2;

        int y = panelTop + 26;

        // --- Colors ---
        colorsLabelY = y;
        y += 14;
        y = addColorButtons(centerX, y);

        // --- Style ---
        y += 12;
        styleLabelY = y;
        y += 14;
        y = addStyleButtons(centerX, y);

        // --- Size ---
        y += 12;
        sizeLabelY = y;
        y += 14;
        int sliderWidth = 260;
        IntStepSlider sizeSlider = new IntStepSlider(centerX - sliderWidth / 2, y, sliderWidth, 20,
                "Size", 10, 200, 5, TargetEspConfig.sizeValue, value -> {
            TargetEspConfig.sizeValue = value;
            TargetEspConfig.save();
        });
        trackWidget(sizeSlider);
        y += 20;

        // --- Turn Speed ---
        y += 12;
        turnSpeedLabelY = y;
        y += 14;
        int offBtnWidth = 50;
        int gapAfterOff = 6;
        int speedSliderWidth = sliderWidth - offBtnWidth - gapAfterOff;
        int rowStartX = centerX - sliderWidth / 2;

        turnSpeedOffButton = ButtonWidget.builder(offLabel(), btn -> {
                    TargetEspConfig.spinEnabled = !TargetEspConfig.spinEnabled;
                    TargetEspConfig.save();
                    turnSpeedOffButton.setMessage(offLabel());
                })
                .dimensions(rowStartX, y, offBtnWidth, 20)
                .build();
        trackWidget(turnSpeedOffButton);

        IntStepSlider turnSpeedSlider = new IntStepSlider(rowStartX + offBtnWidth + gapAfterOff, y, speedSliderWidth, 20,
                "Turn Speed", 10, 200, 5, TargetEspConfig.turnSpeedValue, value -> {
            TargetEspConfig.turnSpeedValue = value;
            TargetEspConfig.save();
        });
        trackWidget(turnSpeedSlider);
        y += 20;

        // --- Duration ---
        y += 14;
        durationLabelY = y;
        y += 14;
        y = addDurationButtons(centerX, y);

        // --- Position ---
        y += 12;
        positionLabelY = y;
        y += 14;
        y = addPositionButtons(centerX, y);

        // --- Key Bindings ---
        y += 14;
        keyBindingsLabelY = y;
        y += 16;

        int keyBtnWidth = 270;
        int keyBtnX = centerX - keyBtnWidth / 2;

        menuKeyButton = ButtonWidget.builder(Text.literal(""), btn -> {
                    listeningFor = TargetEspKeybind.getMenuKey();
                    refreshKeybindLabels();
                })
                .dimensions(keyBtnX, y, keyBtnWidth, 20)
                .build();
        trackWidget(menuKeyButton);
        y += 24;

        toggleKeyButton = ButtonWidget.builder(Text.literal(""), btn -> {
                    listeningFor = TargetEspKeybind.getToggleKey();
                    refreshKeybindLabels();
                })
                .dimensions(keyBtnX, y, keyBtnWidth, 20)
                .build();
        trackWidget(toggleKeyButton);
        refreshKeybindLabels();
        y += 30;

        ButtonWidget exitButton = ButtonWidget.builder(Text.literal("Exit"), btn -> close())
                .dimensions(centerX - 50, y, 100, 20)
                .build();
        trackWidget(exitButton);
    }

    /** Widget'i ekler ve sinirlarini, sonradan beyaz kenarlik cizebilmek icin kaydeder. */
    private void trackWidget(ClickableWidget widget) {
        this.addDrawableChild(widget);
        widgetBounds.add(new int[]{widget.getX(), widget.getY(), widget.getWidth(), widget.getHeight()});
    }

    private int addColorButtons(int centerX, int y) {
        int btnW = 68;
        int btnH = 20;
        int gap = 4;

        placeColorRow(centerX, y, btnW, btnH, gap, 0, 4);
        y += btnH + gap;
        placeColorRow(centerX, y, btnW, btnH, gap, 4, 8);
        y += btnH;
        return y;
    }

    private void placeColorRow(int centerX, int y, int btnW, int btnH, int gap, int fromIndex, int toIndex) {
        int count = toIndex - fromIndex;
        int totalWidth = count * btnW + (count - 1) * gap;
        int x = centerX - totalWidth / 2;

        for (int i = fromIndex; i < toIndex; i++) {
            TargetEspColor c = COLOR_DISPLAY_ORDER[i];
            boolean selected = TargetEspConfig.color == c;
            ButtonWidget button = ButtonWidget.builder(colorLabel(c, selected), btn -> {
                        if (c.custom) {
                            if (this.client != null) {
                                this.client.setScreen(new TargetEspCustomColorScreen(this));
                            }
                        } else {
                            TargetEspConfig.color = c;
                            TargetEspConfig.save();
                            rebuild();
                        }
                    })
                    .dimensions(x, y, btnW, btnH)
                    .build();
            trackWidget(button);
            x += btnW + gap;
        }
    }

    /** Oklar ("> " / " <") her zaman beyaz kalir, sadece isim renklenir. */
    private Text colorLabel(TargetEspColor c, boolean selected) {
        MutableText result = Text.literal("");
        if (selected) {
            result = result.append(Text.literal("> ").formatted(Formatting.WHITE));
        }

        if (c.chroma) {
            String word = c.label;
            for (int i = 0; i < word.length(); i++) {
                float hue = (float) i / word.length();
                int rgb = MathHelper.hsvToRgb(hue, 0.85f, 1f) & 0xFFFFFF;
                result = result.append(Text.literal(String.valueOf(word.charAt(i))).withColor(rgb));
            }
        } else if (c.custom) {
            int rgb = (TargetEspConfig.customR << 16) | (TargetEspConfig.customG << 8) | TargetEspConfig.customB;
            result = result.append(Text.literal(c.label).withColor(rgb));
        } else {
            result = result.append(Text.literal(c.label).withColor(c.packedRgb()));
        }

        if (selected) {
            result = result.append(Text.literal(" <").formatted(Formatting.WHITE));
        }
        return result;
    }

    private int addStyleButtons(int centerX, int y) {
        TargetEspStyle[] styles = TargetEspStyle.values(); // 6 adet
        int btnW = 90;
        int btnH = 20;
        int gap = 6;

        placeStyleRow(centerX, y, btnW, btnH, gap, styles, 0, 3);
        y += btnH + gap;
        placeStyleRow(centerX, y, btnW, btnH, gap, styles, 3, 6);
        y += btnH;
        return y;
    }

    private void placeStyleRow(int centerX, int y, int btnW, int btnH, int gap,
                                TargetEspStyle[] styles, int fromIndex, int toIndex) {
        int count = toIndex - fromIndex;
        int totalWidth = count * btnW + (count - 1) * gap;
        int x = centerX - totalWidth / 2;

        for (int i = fromIndex; i < toIndex; i++) {
            TargetEspStyle s = styles[i];
            boolean selected = TargetEspConfig.style == s;
            MutableText text = Text.literal("");
            if (selected) text = text.append(Text.literal("> ").formatted(Formatting.WHITE));
            text = text.append(Text.literal(s.label).formatted(selected ? Formatting.AQUA : Formatting.GRAY));
            if (selected) text = text.append(Text.literal(" <").formatted(Formatting.WHITE));

            ButtonWidget button = ButtonWidget.builder(text, btn -> {
                        TargetEspConfig.style = s;
                        TargetEspConfig.save();
                        rebuild();
                    })
                    .dimensions(x, y, btnW, btnH)
                    .build();
            trackWidget(button);
            x += btnW + gap;
        }
    }

    private int addDurationButtons(int centerX, int y) {
        TargetEspDuration[] durations = TargetEspDuration.values();
        int btnW = 68;
        int btnH = 18;
        int gap = 4;

        placeDurationRow(centerX, y, btnW, btnH, gap, durations, 0, 3);
        y += btnH + gap;
        placeDurationRow(centerX, y, btnW, btnH, gap, durations, 3, 6);
        y += btnH;
        return y;
    }

    private void placeDurationRow(int centerX, int y, int btnW, int btnH, int gap,
                                   TargetEspDuration[] durations, int fromIndex, int toIndex) {
        int count = toIndex - fromIndex;
        int totalWidth = count * btnW + (count - 1) * gap;
        int x = centerX - totalWidth / 2;

        for (int i = fromIndex; i < toIndex; i++) {
            TargetEspDuration d = durations[i];
            boolean selected = TargetEspConfig.duration == d;
            MutableText text = Text.literal("");
            if (selected) text = text.append(Text.literal("> ").formatted(Formatting.WHITE));
            text = text.append(Text.literal(d.label).formatted(selected ? Formatting.YELLOW : Formatting.GRAY));
            if (selected) text = text.append(Text.literal(" <").formatted(Formatting.WHITE));

            ButtonWidget button = ButtonWidget.builder(text, btn -> {
                        TargetEspConfig.duration = d;
                        TargetEspConfig.save();
                        rebuild();
                    })
                    .dimensions(x, y, btnW, btnH)
                    .build();
            trackWidget(button);
            x += btnW + gap;
        }
    }

    /** Donme kapatildiginda "OFF" butonu vurgulanir. */
    private Text offLabel() {
        return Text.literal("OFF").formatted(TargetEspConfig.spinEnabled ? Formatting.GRAY : Formatting.RED);
    }

    private int addPositionButtons(int centerX, int y) {
        TargetEspPosition[] positions = TargetEspPosition.values(); // 3 adet
        int btnW = 90;
        int btnH = 20;
        int gap = 6;
        int count = positions.length;
        int totalWidth = count * btnW + (count - 1) * gap;
        int x = centerX - totalWidth / 2;

        for (TargetEspPosition p : positions) {
            boolean selected = TargetEspConfig.position == p;
            MutableText text = Text.literal("");
            if (selected) text = text.append(Text.literal("> ").formatted(Formatting.WHITE));
            text = text.append(Text.literal(p.label).formatted(selected ? Formatting.GREEN : Formatting.GRAY));
            if (selected) text = text.append(Text.literal(" <").formatted(Formatting.WHITE));

            ButtonWidget button = ButtonWidget.builder(text, btn -> {
                        TargetEspConfig.position = p;
                        TargetEspConfig.save();
                        rebuild();
                    })
                    .dimensions(x, y, btnW, btnH)
                    .build();
            trackWidget(button);
            x += btnW + gap;
        }
        y += btnH;
        return y;
    }

    private void rebuild() {
        if (this.client != null) {
            this.client.setScreen(new TargetEspScreen(parent));
        }
    }

    private void refreshKeybindLabels() {
        boolean waitingMenu = listeningFor == TargetEspKeybind.getMenuKey();
        boolean waitingToggle = listeningFor == TargetEspKeybind.getToggleKey();

        menuKeyButton.setMessage(waitingMenu
                ? Text.literal("Open Menu > Press a key...").formatted(Formatting.YELLOW)
                : Text.literal("Open Menu: ").append(TargetEspKeybind.getMenuKey().getBoundKeyLocalizedText()));

        toggleKeyButton.setMessage(waitingToggle
                ? Text.literal("Toggle TargetRing > Press a key...").formatted(Formatting.YELLOW)
                : Text.literal("Toggle TargetRing: ").append(TargetEspKeybind.getToggleKey().getBoundKeyLocalizedText()));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listeningFor != null) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                listeningFor.setBoundKey(InputUtil.Type.KEYSYM.createFromCode(keyCode));
                KeyBinding.updateKeysByCode();
                if (this.client != null) {
                    this.client.options.write();
                }
            }
            listeningFor = null;
            refreshKeybindLabels();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0x88000000);

        TargetEspGuiUtil.drawTexturedQuad(context, BACKGROUND_TEXTURE, panelLeft, panelTop, PANEL_WIDTH, PANEL_HEIGHT);
        context.drawBorder(panelLeft, panelTop, PANEL_WIDTH, PANEL_HEIGHT, 0xA0FFFFFF);

        super.render(context, mouseX, mouseY, delta);

        for (int[] b : widgetBounds) {
            context.drawBorder(b[0], b[1], b[2], b[3], 0x90FFFFFF);
        }

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, panelTop + 10, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Colors"),
                this.width / 2, colorsLabelY, 0xEEEEEE);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Style"),
                this.width / 2, styleLabelY, 0xEEEEEE);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Size"),
                this.width / 2, sizeLabelY, 0xEEEEEE);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Turn Speed"),
                this.width / 2, turnSpeedLabelY, 0xEEEEEE);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Duration"),
                this.width / 2, durationLabelY, 0xEEEEEE);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Position"),
                this.width / 2, positionLabelY, 0xEEEEEE);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Key Bindings"),
                this.width / 2, keyBindingsLabelY, 0xEEEEEE);
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
