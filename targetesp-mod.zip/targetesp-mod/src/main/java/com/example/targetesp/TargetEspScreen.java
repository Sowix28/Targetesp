package com.example.targetesp;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

/**
 * TargetESP icin ozel ayar ekrani. Renk, sure ve tus atamalarini
 * degistirmeye yariyor. Hem oyun ici K tusuyla, hem de Mod Menu
 * ("Configure...") uzerinden acilabilir.
 */
public class TargetEspScreen extends Screen {

    private final Screen parent;

    private ButtonWidget menuKeyButton;
    private ButtonWidget toggleKeyButton;

    /** Su an hangi tus atamasi icin yeni tus bekleniyor (null ise bekleme yok). */
    private KeyBinding listeningFor = null;

    private int panelLeft;
    private int panelTop;
    private static final int PANEL_WIDTH = 300;
    private static final int PANEL_HEIGHT = 250;

    public TargetEspScreen(Screen parent) {
        super(Text.literal("TargetESP Ayarlari"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();

        this.panelLeft = this.width / 2 - PANEL_WIDTH / 2;
        this.panelTop = this.height / 2 - PANEL_HEIGHT / 2;
        int centerX = this.width / 2;

        int y = panelTop + 30;

        // --- Renkler ---
        y += 12; // "Renkler" etiketi icin bosluk (metin render()'da ciziliyor)
        y = addColorButtons(centerX, y);

        // --- Sure ---
        y += 16;
        y = addDurationButtons(centerX, y);

        // --- Tus atamalari ---
        y += 16;
        int keyBtnWidth = 260;
        int keyBtnX = centerX - keyBtnWidth / 2;

        menuKeyButton = ButtonWidget.builder(Text.literal(""), btn -> {
                    listeningFor = TargetEspKeybind.getMenuKey();
                    refreshKeybindLabels();
                })
                .dimensions(keyBtnX, y, keyBtnWidth, 20)
                .build();
        this.addDrawableChild(menuKeyButton);
        y += 24;

        toggleKeyButton = ButtonWidget.builder(Text.literal(""), btn -> {
                    listeningFor = TargetEspKeybind.getToggleKey();
                    refreshKeybindLabels();
                })
                .dimensions(keyBtnX, y, keyBtnWidth, 20)
                .build();
        this.addDrawableChild(toggleKeyButton);
        refreshKeybindLabels();

        y += 30;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Kapat"), btn -> close())
                .dimensions(centerX - 50, y, 100, 20)
                .build());
    }

    private int addColorButtons(int centerX, int y) {
        TargetEspColor[] colors = TargetEspColor.values();
        int btnW = 64;
        int btnH = 20;
        int gap = 4;

        // Ilk 4 renk
        placeRow(centerX, y, btnW, btnH, gap, colors, 0, 4);
        y += btnH + gap;
        // Kalan 3 renk
        placeRow(centerX, y, btnW, btnH, gap, colors, 4, 7);
        y += btnH;
        return y;
    }

    private void placeRow(int centerX, int y, int btnW, int btnH, int gap,
                           TargetEspColor[] colors, int fromIndex, int toIndex) {
        int count = toIndex - fromIndex;
        int totalWidth = count * btnW + (count - 1) * gap;
        int x = centerX - totalWidth / 2;

        for (int i = fromIndex; i < toIndex; i++) {
            TargetEspColor c = colors[i];
            boolean selected = TargetEspConfig.color == c;
            ButtonWidget button = ButtonWidget.builder(colorLabel(c, selected), btn -> {
                        TargetEspConfig.color = c;
                        TargetEspConfig.save();
                        rebuild();
                    })
                    .dimensions(x, y, btnW, btnH)
                    .build();
            this.addDrawableChild(button);
            x += btnW + gap;
        }
    }

    private Text colorLabel(TargetEspColor c, boolean selected) {
        String text = (selected ? "> " : "") + c.label + (selected ? " <" : "");
        if (c.chroma) {
            return Text.literal(text).formatted(selected ? Formatting.WHITE : Formatting.GRAY);
        }
        return Text.literal(text).withColor(c.packedRgb());
    }

    private int addDurationButtons(int centerX, int y) {
        TargetEspDuration[] durations = TargetEspDuration.values();
        int btnW = 64;
        int btnH = 18;
        int gap = 4;

        placeDurationRow(centerX, y, btnW, btnH, gap, durations, 0, 3);
        y += btnH + gap;
        placeDurationRow(centerX, y, btnW, btnH, gap, durations, 3, 6);
        y += btnH;
        return y;
    }

    private void placeDurationRow(int centerX, int y, int btnW, int btnH, int gap,
                                   TargetEspDuration[] durations, int fromIndex, int toIndex) {
        int count = toIndex - fromIndex;
        int totalWidth = count * btnW + (count - 1) * gap;
        int x = centerX - totalWidth / 2;

        for (int i = fromIndex; i < toIndex; i++) {
            TargetEspDuration d = durations[i];
            boolean selected = TargetEspConfig.duration == d;
            String text = (selected ? "> " : "") + d.label + (selected ? " <" : "");
            ButtonWidget button = ButtonWidget.builder(
                            Text.literal(text).formatted(selected ? Formatting.YELLOW : Formatting.GRAY),
                            btn -> {
                                TargetEspConfig.duration = d;
                                TargetEspConfig.save();
                                rebuild();
                            })
                    .dimensions(x, y, btnW, btnH)
                    .build();
            this.addDrawableChild(button);
            x += btnW + gap;
        }
    }

    private void rebuild() {
        if (this.client != null) {
            this.client.setScreen(new TargetEspScreen(parent));
        }
    }

    private void refreshKeybindLabels() {
        boolean waitingMenu = listeningFor == TargetEspKeybind.getMenuKey();
        boolean waitingToggle = listeningFor == TargetEspKeybind.getToggleKey();

        menuKeyButton.setMessage(waitingMenu
                ? Text.literal("Menuyu Ac > Bir tusa bas...").formatted(Formatting.YELLOW)
                : Text.literal("Menuyu Ac: ").append(TargetEspKeybind.getMenuKey().getBoundKeyLocalizedText()));

        toggleKeyButton.setMessage(waitingToggle
                ? Text.literal("TargetESP Ac/Kapat > Bir tusa bas...").formatted(Formatting.YELLOW)
                : Text.literal("TargetESP Ac/Kapat: ").append(TargetEspKeybind.getToggleKey().getBoundKeyLocalizedText()));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listeningFor != null) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                listeningFor.setBoundKey(InputUtil.Type.KEYSYM.createFromCode(keyCode));
                KeyBinding.updateKeysByCode();
                if (this.client != null) {
                    this.client.options.write();
                }
            }
            listeningFor = null;
            refreshKeybindLabels();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Arka planı hafifce karart
        context.fill(0, 0, this.width, this.height, 0x88000000);

        // Panel govdesi ve kenarligi
        context.fill(panelLeft, panelTop, panelLeft + PANEL_WIDTH, panelTop + PANEL_HEIGHT, 0xE6101018);
        context.drawBorder(panelLeft, panelTop, PANEL_WIDTH, PANEL_HEIGHT, 0xFF4A4A6A);

        super.render(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, panelTop + 10, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Renkler"),
                this.width / 2, panelTop + 32, 0xAAAAAA);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Sure"),
                this.width / 2, panelTop + 94, 0xAAAAAA);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Tus Atamalari"),
                this.width / 2, panelTop + 158, 0xAAAAAA);
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
