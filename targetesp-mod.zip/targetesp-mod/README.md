# TargetESP (RGB Ring)

Fabric 1.21.4 icin, baktigin canlinin uzerinde donen, renk degistiren
(RGB) bir halka gosteren basit bir mod. K3D'nin kodu kullanilmadi;
sadece gorsel davranis referans alinarak sifirdan yazildi. Texture
(halka gorseli) K3D'nin acik kaynak asset dosyasindan alindi.

## Nasil derlenir

Bunu DERLEMEK icin internet baglantisi ve JDK 21 gerekiyor -
bu ortamda (Claude'un calisma alaninda) internetim olmadigi icin
projeyi ben derleyemedim, sadece kaynak kodu hazirladim.

1. Bilgisayarina JDK 21 kur (https://adoptium.net/)
2. Bu klasoru bir yere cikart
3. Terminal/CMD'de klasore gir
4. Calistir:
   - Windows: `gradlew.bat build`
   - Mac/Linux: `./gradlew build`
   (Not: `gradlew` / `gradlew.bat` dosyalari bu projede yok, cunku
   Gradle wrapper jar'ini indirmek icin internet gerekiyor. Bunun
   yerine bilgisayarinda kurulu Gradle'i kullanabilir, ya da IntelliJ
   IDEA'da projeyi actiginda IDE otomatik olarak wrapper'i indirmeni
   isteyecektir - o zaman sorun kalmaz.)
5. Basarili olursa, `.jar` dosyasi `build/libs/` klasorunde olusur
6. O jar'i `.minecraft/mods` klasorune, Fabric Loader ve Fabric API
   ile birlikte koy

## Eger derleme hata verirse

`gradle.properties` dosyasindaki surum numaralari (yarn_mappings,
loader_version, fabric_version) guncel olmayabilir - ben bunlari
internete erisemedigim icin dogrulayamadim. Hata mesaji genelde
"could not find X" seklinde olur. Bu durumda:

1. https://fabricmc.net/develop adresine git
2. Minecraft surumunu 1.21.4 sec
3. Oradaki guncel numaralari `gradle.properties` dosyasina yaz
4. Tekrar derle

## Kullanim

Oyun icinde varsayilan olarak **T** tusuna basarak acip
kapatabilirsin. Ayarlari degistirmek istersen
`TargetEspConfig.java` dosyasindaki degerleri duzenle.

## Eger derleme sirasinda ".next() bulunamadi" hatasi alirsan

`TargetRingRenderer.java` icindeki `drawVertex` metodunda,
`.next()` satirini sil - kullandigin Minecraft surumu daha yeni
bir vertex API'sine gecmis demektir.
